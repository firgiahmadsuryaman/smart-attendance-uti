﻿$ErrorActionPreference = 'Stop'
$PatchRoot = (Resolve-Path -LiteralPath (Split-Path -Parent $MyInvocation.MyCommand.Path)).Path
$DefaultTarget = Join-Path $env:USERPROFILE 'Downloads\absensi\smart_attendance'
Write-Host ''
Write-Host 'SMART ATTENDANCE UTI - FOTO BUKTI 60 MENIT (TANPA RADIUS)' -ForegroundColor Cyan
Write-Host 'Pemasang hanya menyalin file dalam manifest dan mencadangkan file yang diganti.'
Write-Host 'Tidak mengubah models.py, run.py, .env, .venv, instance, atau database.' -ForegroundColor Green
Write-Host ''
Write-Host ('Folder proyek default: ' + $DefaultTarget) -ForegroundColor Yellow
$InputTarget = Read-Host 'Tekan ENTER jika jalur benar, atau tempel jalur folder proyek yang berisi run.py'
if ([string]::IsNullOrWhiteSpace($InputTarget)) { $InputTarget = $DefaultTarget }
if (-not (Test-Path -LiteralPath $InputTarget -PathType Container)) { throw "Folder proyek tidak ditemukan: $InputTarget" }
$ProjectRoot = (Resolve-Path -LiteralPath $InputTarget).Path
if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot 'run.py') -PathType Leaf) -or -not (Test-Path -LiteralPath (Join-Path $ProjectRoot 'app') -PathType Container)) { throw 'Folder yang dipilih bukan folder proyek Smart Attendance (run.py dan app wajib ada).' }
if ($ProjectRoot -eq $PatchRoot) { throw 'Folder patch tidak boleh dipilih sebagai folder proyek.' }
$Manifest = Join-Path $PatchRoot 'MANIFEST_FOTO_BUKTI_60M.txt'
if (-not (Test-Path -LiteralPath $Manifest -PathType Leaf)) { throw 'Manifest tidak ditemukan; ekstrak seluruh ZIP.' }
$Files = @()
foreach ($line in Get-Content -LiteralPath $Manifest) {
  $rel = $line.Trim().Replace('/', '\')
  if ([string]::IsNullOrWhiteSpace($rel) -or $rel.StartsWith('#')) { continue }
  if ([System.IO.Path]::IsPathRooted($rel) -or $rel -match '(^|\\)\.\.(\\|$)') { throw "Jalur tidak aman: $rel" }
  if ($rel -in @('.env','app\models.py','run.py') -or $rel -match '(^|\\)(\.venv|instance|database)(\\|$)') { throw "File terlindungi tidak boleh masuk manifest: $rel" }
  $src = Join-Path $PatchRoot $rel
  if (-not (Test-Path -LiteralPath $src -PathType Leaf)) { throw "File patch tidak ditemukan: $rel" }
  $Files += $rel
}
Write-Host ''
Write-Host ("Target proyek: $ProjectRoot")
Write-Host ("File yang akan dipasang: $($Files.Count)")
Write-Host 'Radius lokasi akan dinonaktifkan untuk sesi baru dan tidak lagi diverifikasi saat presensi.' -ForegroundColor Yellow
Write-Host 'Foto bukti akan disimpan privat maksimal 60 menit, lalu dihapus dari folder server.' -ForegroundColor Yellow
$confirm = Read-Host 'Untuk melanjutkan, ketik PASANG FOTO 60M'
if ($confirm -cne 'PASANG FOTO 60M') { Write-Host 'Dibatalkan; proyek tidak diubah.' -ForegroundColor Yellow; exit 0 }
$Parent = Split-Path -Parent $ProjectRoot
$Leaf = Split-Path -Leaf $ProjectRoot
$Stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$BackupRoot = Join-Path $Parent ("{0}_backup_FOTO_60M_{1}" -f $Leaf,$Stamp)
New-Item -ItemType Directory -Path $BackupRoot -Force | Out-Null
$existing = New-Object System.Collections.Generic.List[string]
$newFiles = New-Object System.Collections.Generic.List[string]
foreach ($rel in $Files) {
  $dst = Join-Path $ProjectRoot $rel
  if (Test-Path -LiteralPath $dst -PathType Leaf) {
    $backupFile = Join-Path $BackupRoot $rel
    $backupParent = Split-Path -Parent $backupFile
    if (-not (Test-Path -LiteralPath $backupParent)) { New-Item -ItemType Directory -Path $backupParent -Force | Out-Null }
    Copy-Item -LiteralPath $dst -Destination $backupFile -Force
    $existing.Add($rel)
  } else { $newFiles.Add($rel) }
}
$existing | Set-Content -LiteralPath (Join-Path $BackupRoot 'FILES_BACKED_UP.txt') -Encoding UTF8
$newFiles | Set-Content -LiteralPath (Join-Path $BackupRoot 'FILES_NEW_IN_PROJECT.txt') -Encoding UTF8
$escapedProject = $ProjectRoot.Replace("'","''")
$restoreScript = @"
`$ErrorActionPreference = 'Stop'
`$ProjectRoot = '$escapedProject'
`$BackupRoot = (Resolve-Path -LiteralPath (Split-Path -Parent `$MyInvocation.MyCommand.Path)).Path
`$restored = 0
`$list = Join-Path `$BackupRoot 'FILES_BACKED_UP.txt'
if (Test-Path -LiteralPath `$list) { foreach (`$rel in Get-Content -LiteralPath `$list) { `$rel=`$rel.Trim(); if ([string]::IsNullOrWhiteSpace(`$rel)) {continue}; `$src=Join-Path `$BackupRoot `$rel; `$dst=Join-Path `$ProjectRoot `$rel; if (Test-Path -LiteralPath `$src -PathType Leaf) { `$p=Split-Path -Parent `$dst; if (-not(Test-Path -LiteralPath `$p)) {New-Item -ItemType Directory -Path `$p -Force|Out-Null}; Copy-Item -LiteralPath `$src -Destination `$dst -Force; `$restored++ } } }
`$listNew = Join-Path `$BackupRoot 'FILES_NEW_IN_PROJECT.txt'
`$removed=0
if (Test-Path -LiteralPath `$listNew) { foreach (`$rel in Get-Content -LiteralPath `$listNew) { `$rel=`$rel.Trim(); if ([string]::IsNullOrWhiteSpace(`$rel)) {continue}; `$dst=Join-Path `$ProjectRoot `$rel; if (Test-Path -LiteralPath `$dst -PathType Leaf) {Remove-Item -LiteralPath `$dst -Force; `$removed++} } }
Write-Host 'Rollback selesai. File lama dipulihkan: ' `$restored '; file baru dihapus: ' `$removed -ForegroundColor Green
Read-Host 'Tekan ENTER untuk menutup'
"@
Set-Content -LiteralPath (Join-Path $BackupRoot 'PULIHKAN_BACKUP_FOTO_60M.ps1') -Value $restoreScript -Encoding UTF8
$restoreBat = @'
@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0PULIHKAN_BACKUP_FOTO_60M.ps1"
pause
'@
Set-Content -LiteralPath (Join-Path $BackupRoot 'PULIHKAN_BACKUP_FOTO_60M.bat') -Value $restoreBat -Encoding ASCII
try {
  foreach ($rel in $Files) {
    $src = Join-Path $PatchRoot $rel
    $dst = Join-Path $ProjectRoot $rel
    $p = Split-Path -Parent $dst
    if (-not (Test-Path -LiteralPath $p)) { New-Item -ItemType Directory -Path $p -Force | Out-Null }
    Copy-Item -LiteralPath $src -Destination $dst -Force
  }
} catch { Write-Host 'Pemasangan gagal saat menyalin. Gunakan PULIHKAN_BACKUP_FOTO_60M.bat di folder backup.' -ForegroundColor Red; throw }
Write-Host ''
Write-Host 'FILE PATCH TERPASANG.' -ForegroundColor Green
Write-Host ("Cadangan: $BackupRoot") -ForegroundColor Cyan
Write-Host 'Langkah berikutnya: buka SETUP_PENGHAPUS_OTOMATIS_60M.bat dari paket patch agar Task Scheduler membersihkan foto setiap menit.' -ForegroundColor Yellow
Write-Host 'Setelah scheduler dibuat, jalankan python run.py seperti biasa.'
Read-Host 'Tekan ENTER untuk menutup'
