@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0SETUP_PENGHAPUS_OTOMATIS_60M.ps1"
if errorlevel 1 (echo. & echo Tugas otomatis belum berhasil dibuat. Baca panduan, lalu kirim screenshot error. & pause)
