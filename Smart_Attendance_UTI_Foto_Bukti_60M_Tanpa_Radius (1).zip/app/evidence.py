"""Private, short-lived photo evidence for successful attendance checks.

Evidence files live under instance/attendance_evidence, never under static/.
Their server-side filesystem mtime starts the 60-minute retention period.
"""
from __future__ import annotations

import base64
import binascii
import os
import re
import time
from pathlib import Path
from typing import Optional

RETENTION_SECONDS = 60 * 60
MAX_INPUT_BYTES = 5 * 1024 * 1024
MAX_IMAGE_DIMENSION = 960
JPEG_QUALITY = 78
DATA_URL_RE = re.compile(r"^data:image/(?:jpeg|jpg|png);base64,([A-Za-z0-9+/=\r\n]+)$", re.IGNORECASE)
FILENAME_RE = re.compile(r"^attendance_(\d+)\.jpg$")


class EvidenceStorageError(RuntimeError):
    """Raised when a valid evidence frame cannot be normalized and stored."""


def evidence_directory(instance_path: str | os.PathLike) -> Path:
    return Path(instance_path).resolve() / "attendance_evidence"


def evidence_path(instance_path: str | os.PathLike, attendance_id: int) -> Path:
    # A fixed filename is acceptable because files are private and every read is authorized.
    return evidence_directory(instance_path) / f"attendance_{int(attendance_id)}.jpg"


def save_attendance_evidence(data_url: str, attendance_id: int, instance_path: str | os.PathLike) -> Path:
    """Validate a camera data URL, re-encode to JPEG, and atomically store it privately."""
    if not isinstance(data_url, str) or len(data_url) < 30:
        raise EvidenceStorageError("Frame bukti foto kosong atau tidak valid.")
    match = DATA_URL_RE.match(data_url.strip())
    if not match:
        raise EvidenceStorageError("Frame bukti harus berupa gambar kamera JPEG/PNG yang valid.")
    try:
        raw = base64.b64decode(match.group(1), validate=True)
    except (binascii.Error, ValueError) as exc:
        raise EvidenceStorageError("Data gambar bukti tidak valid.") from exc
    if not raw or len(raw) > MAX_INPUT_BYTES:
        raise EvidenceStorageError("Ukuran foto bukti melebihi batas aman.")

    try:
        import cv2
        import numpy as np
        buffer = np.frombuffer(raw, dtype=np.uint8)
        image = cv2.imdecode(buffer, cv2.IMREAD_COLOR)
        if image is None or len(image.shape) != 3:
            raise EvidenceStorageError("Server tidak dapat membaca frame kamera sebagai gambar.")
        height, width = image.shape[:2]
        if width < 64 or height < 64:
            raise EvidenceStorageError("Resolusi foto bukti terlalu kecil.")
        scale = min(1.0, MAX_IMAGE_DIMENSION / float(max(width, height)))
        if scale < 1.0:
            new_size = (max(1, round(width * scale)), max(1, round(height * scale)))
            image = cv2.resize(image, new_size, interpolation=cv2.INTER_AREA)
        ok, encoded = cv2.imencode(".jpg", image, [int(cv2.IMWRITE_JPEG_QUALITY), JPEG_QUALITY])
        if not ok:
            raise EvidenceStorageError("Server gagal mengompres foto bukti.")
        output = encoded.tobytes()
    except EvidenceStorageError:
        raise
    except Exception as exc:
        raise EvidenceStorageError("Pemrosesan foto bukti gagal. Coba ulangi presensi.") from exc

    folder = evidence_directory(instance_path)
    try:
        folder.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(folder, 0o700)
        except OSError:
            pass
        target = evidence_path(instance_path, attendance_id)
        temp = folder / f".attendance_{int(attendance_id)}_{os.getpid()}_{time.time_ns()}.tmp"
        with open(temp, "xb") as handle:
            handle.write(output)
            handle.flush()
            os.fsync(handle.fileno())
        try:
            os.chmod(temp, 0o600)
        except OSError:
            pass
        os.replace(temp, target)
        # Set the retention clock from server time at the moment the file is written.
        now = time.time()
        os.utime(target, (now, now))
        return target
    except Exception as exc:
        try:
            if 'temp' in locals() and temp.exists():
                temp.unlink()
        except OSError:
            pass
        raise EvidenceStorageError("Foto bukti tidak dapat disimpan di penyimpanan privat server.") from exc


def is_evidence_available(instance_path: str | os.PathLike, attendance_id: int, *, remove_expired: bool = True) -> bool:
    path = evidence_path(instance_path, attendance_id)
    try:
        stat = path.stat()
    except FileNotFoundError:
        return False
    except OSError:
        return False
    if time.time() - stat.st_mtime >= RETENTION_SECONDS:
        if remove_expired:
            try:
                path.unlink(missing_ok=True)
            except OSError:
                pass
        return False
    return True


def remove_attendance_evidence(instance_path: str | os.PathLike, attendance_id: int) -> None:
    try:
        evidence_path(instance_path, attendance_id).unlink(missing_ok=True)
    except OSError:
        pass


def cleanup_expired_evidence(instance_path: str | os.PathLike) -> int:
    """Delete evidence files older than 60 minutes; return number of deleted images."""
    folder = evidence_directory(instance_path)
    if not folder.exists():
        return 0
    now = time.time()
    deleted = 0
    try:
        paths = list(folder.iterdir())
    except OSError:
        return 0
    for path in paths:
        try:
            if not path.is_file():
                continue
            match = FILENAME_RE.match(path.name)
            is_temp = path.name.startswith('.attendance_') and path.name.endswith('.tmp')
            if match:
                expired = now - path.stat().st_mtime >= RETENTION_SECONDS
            elif is_temp:
                # Only clean abandoned temporary files, with a shorter safe grace period.
                expired = now - path.stat().st_mtime >= 10 * 60
            else:
                continue
            if expired:
                path.unlink()
                if match:
                    deleted += 1
        except FileNotFoundError:
            continue
        except OSError:
            # Retry on a future scheduled run. Do not disrupt an attendance request.
            continue
    return deleted
