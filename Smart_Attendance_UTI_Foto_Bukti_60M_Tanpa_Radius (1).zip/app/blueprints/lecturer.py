from datetime import date, datetime, time, timedelta
from io import BytesIO
import base64
import json
import os
import secrets
import string
from flask import Blueprint, abort, current_app, flash, make_response, redirect, render_template, request, send_file, url_for
from flask_login import login_required, current_user
from sqlalchemy.exc import IntegrityError
from ..extensions import db
from ..models import (User, StudyProgram, Semester, Course, ClassOffering, ClassSchedule,
                      CourseEnrollment, AttendanceSession, Attendance, Notification)
from ..utils import role_required, log_action, get_active_semester
from ..evidence import cleanup_expired_evidence, evidence_path, is_evidence_available

lecturer_bp = Blueprint("lecturer", __name__, url_prefix="/lecturer")
WEEKDAYS = [(0, "Senin"), (1, "Selasa"), (2, "Rabu"), (3, "Kamis"), (4, "Jumat"), (5, "Sabtu"), (6, "Minggu")]
WEEKDAY_NAMES = [label for _, label in WEEKDAYS]


def _owned_offering(offering_id):
    return ClassOffering.query.filter_by(id=offering_id, lecturer_id=current_user.id).first_or_404()


def _owned_session(session_id):
    session = db.get_or_404(AttendanceSession, session_id)
    if session.offering.lecturer_id != current_user.id:
        abort(403)
    return session


def _parse_time(value):
    return datetime.strptime(value, "%H:%M").time()


def _slots_from_form(delivery_mode):
    weekdays = request.form.getlist("weekday[]")
    starts = request.form.getlist("start_time[]")
    ends = request.form.getlist("end_time[]")
    rooms = request.form.getlist("room[]")
    slots = []
    for i in range(max(len(weekdays), len(starts), len(ends), len(rooms))):
        wd = weekdays[i] if i < len(weekdays) else ""
        start = starts[i] if i < len(starts) else ""
        end = ends[i] if i < len(ends) else ""
        room = rooms[i] if i < len(rooms) else ""
        if not str(wd).strip() and not str(start).strip() and not str(end).strip():
            continue
        try:
            weekday = int(wd)
            start_time, end_time = _parse_time(start), _parse_time(end)
        except (ValueError, TypeError):
            raise ValueError("Setiap slot jadwal wajib memiliki hari, jam mulai, dan jam selesai yang valid.")
        room = (room or "").strip()
        if delivery_mode == "ONLINE":
            room = room or "Online"
        if weekday not in range(7) or start_time >= end_time:
            raise ValueError("Hari atau rentang waktu jadwal tidak valid.")
        if delivery_mode == "OFFLINE" and not room:
            raise ValueError("Ruang wajib diisi untuk kelas tatap muka.")
        slots.append({"weekday": weekday, "start_time": start_time, "end_time": end_time, "room": room or "Online"})
    if not slots:
        raise ValueError("Tambahkan minimal satu jadwal mingguan.")
    for i, one in enumerate(slots):
        for other in slots[i + 1:]:
            if one["weekday"] == other["weekday"] and one["start_time"] < other["end_time"] and other["start_time"] < one["end_time"]:
                raise ValueError("Dua slot jadwal yang dibuat saling bertabrakan.")
    return slots


def _validate_conflicts(semester_id, lecturer_id, slots, delivery_mode, exclude_offering_id=None):
    query = ClassSchedule.query.join(ClassOffering).filter(ClassOffering.semester_id == semester_id)
    if exclude_offering_id:
        query = query.filter(ClassOffering.id != exclude_offering_id)
    existing_slots = query.all()
    for slot in slots:
        for existing in existing_slots:
            if existing.weekday != slot["weekday"]:
                continue
            overlaps = slot["start_time"] < existing.end_time and existing.start_time < slot["end_time"]
            if not overlaps:
                continue
            if existing.offering.lecturer_id == lecturer_id:
                raise ValueError(f"Jadwal bentrok: Anda sudah mengajar {existing.offering.course.code} {existing.offering.class_code} pada waktu tersebut.")
            if delivery_mode == "OFFLINE" and (existing.offering.delivery_mode or "OFFLINE") == "OFFLINE" and existing.room.casefold() == slot["room"].casefold():
                raise ValueError(f"Ruang {slot['room']} sudah digunakan oleh kelas {existing.offering.course.code} {existing.offering.class_code} pada waktu tersebut.")


def _make_session_qr(session):
    if not session.access_token:
        return None, None
    root = (os.getenv("APP_BASE_URL") or request.host_url).rstrip("/")
    qr_url = root + url_for("student.attendance", token=session.access_token)
    try:
        import qrcode
        qr = qrcode.QRCode(version=2, box_size=7, border=3)
        qr.add_data(qr_url)
        qr.make(fit=True)
        image = qr.make_image(fill_color="#142f56", back_color="white")
        output = BytesIO()
        image.save(output, format="PNG")
        data_uri = "data:image/png;base64," + base64.b64encode(output.getvalue()).decode("ascii")
        return data_uri, qr_url
    except ImportError:
        return None, qr_url


def _attendance_rows(sessions):
    session_ids = [session.id for session in sessions]
    records = Attendance.query.filter(Attendance.session_id.in_(session_ids)).all() if session_ids else []
    return records


def _period_bounds(period):
    now = datetime.now()
    if period == "day":
        start = datetime.combine(now.date(), time.min)
        return start, start + timedelta(days=1), "Harian"
    if period == "month":
        start = datetime(now.year, now.month, 1)
        end = datetime(now.year + (now.month == 12), 1 if now.month == 12 else now.month + 1, 1)
        return start, end, "Bulanan"
    active = get_active_semester()
    if active and active.start_date:
        start = datetime.combine(active.start_date, time.min)
        end = datetime.combine(active.end_date + timedelta(days=1), time.min) if active.end_date else datetime.max
        return start, end, f"Semester · {active.name}"
    return None, None, "Semua Periode"


def _build_xlsx(title, metadata, headers, rows, filename):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    from openpyxl.drawing.image import Image as XLImage

    workbook = Workbook()
    workbook.properties.title = title
    workbook.properties.creator = "Universitas Teknokrat Indonesia · Smart Attendance"
    sheet = workbook.active
    sheet.title = "Jadwal Mengajar"
    sheet.sheet_view.showGridLines = False
    sheet.sheet_properties.tabColor = "2F67C9"
    column_count = max(len(headers), 2)
    sheet.merge_cells(start_row=1, start_column=2, end_row=1, end_column=column_count)
    title_cell = sheet.cell(1, 2, "UNIVERSITAS TEKNOKRAT INDONESIA")
    title_cell.font = Font(name="Aptos Display", size=16, bold=True, color="FFFFFF")
    title_cell.fill = PatternFill("solid", fgColor="173866")
    title_cell.alignment = Alignment(horizontal="left", vertical="center")
    for col in range(2, column_count + 1):
        sheet.cell(1, col).fill = PatternFill("solid", fgColor="173866")
    sheet.row_dimensions[1].height = 42
    logo_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static", "images", "logo-teknokrat.png")
    if os.path.exists(logo_path):
        try:
            logo = XLImage(logo_path)
            logo.height, logo.width = 35, 35
            sheet.add_image(logo, "A1")
        except Exception:
            pass
    sheet.merge_cells(start_row=2, start_column=1, end_row=2, end_column=column_count)
    subtitle = sheet.cell(2, 1, title.upper())
    subtitle.font = Font(size=12, bold=True, color="173866")
    subtitle.alignment = Alignment(horizontal="center", vertical="center")
    sheet.row_dimensions[2].height = 24
    for item in metadata:
        row_num = sheet.max_row + 1
        key = sheet.cell(row_num, 1, str(item[0]))
        key.font = Font(bold=True, color="173866")
        key.fill = PatternFill("solid", fgColor="EDF3FB")
        value = sheet.cell(row_num, 2, str(item[1]))
        value.alignment = Alignment(wrap_text=True, vertical="center")
    sheet.append([])
    sheet.append(headers)
    header_row = sheet.max_row
    for cell in sheet[header_row]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="2456A6")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for row in rows:
        sheet.append([value if value is not None else "-" for value in row])
    thin = Side(style="thin", color="DCE4EF")
    for row in sheet.iter_rows(min_row=header_row, max_row=sheet.max_row, min_col=1, max_col=len(headers)):
        for cell in row:
            cell.border = Border(bottom=thin)
            cell.alignment = Alignment(vertical="center", wrap_text=True)
    for idx in range(1, len(headers) + 1):
        values = [len(str(sheet.cell(r, idx).value or "")) for r in range(header_row, sheet.max_row + 1)]
        sheet.column_dimensions[get_column_letter(idx)].width = min(max(max(values or [12]) + 2, 12), 38)
    for row_idx in range(header_row + 1, sheet.max_row + 1):
        sheet.row_dimensions[row_idx].height = 30 if any(len(str(sheet.cell(row_idx, c).value or "")) > 55 for c in range(1, len(headers) + 1)) else 23
        if (row_idx - header_row) % 2 == 0:
            for col_idx in range(1, len(headers) + 1):
                sheet.cell(row_idx, col_idx).fill = PatternFill("solid", fgColor="F3F7FD")
        for col_idx in range(1, len(headers) + 1):
            cell = sheet.cell(row_idx, col_idx)
            if isinstance(cell.value, str) and cell.value.startswith(("https://", "http://")):
                cell.hyperlink = cell.value
                cell.style = "Hyperlink"
    sheet.freeze_panes = f"A{header_row + 1}"
    sheet.auto_filter.ref = f"A{header_row}:{get_column_letter(len(headers))}{sheet.max_row}"
    sheet.print_title_rows = f"1:{header_row}"
    sheet.page_setup.orientation = "landscape"
    sheet.page_setup.fitToWidth = 1
    sheet.page_setup.fitToHeight = 0
    sheet.sheet_properties.pageSetUpPr.fitToPage = True
    sheet.page_margins.left = 0.25
    sheet.page_margins.right = 0.25
    sheet.page_margins.top = 0.45
    sheet.page_margins.bottom = 0.45
    sheet.oddFooter.center.text = "Sistem Informasi Presensi Mahasiswa · UTI"
    sheet.oddFooter.right.text = "Halaman &P dari &N"
    output = BytesIO()
    workbook.save(output)
    output.seek(0)
    return send_file(output, as_attachment=True, download_name=filename,
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


def _build_pdf(title, metadata, headers, rows, filename):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.enums import TA_CENTER, TA_LEFT
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
    from xml.sax.saxutils import escape

    output = BytesIO()
    page_width = landscape(A4)[0] - 52
    doc = SimpleDocTemplate(output, pagesize=landscape(A4), rightMargin=26, leftMargin=26, topMargin=25, bottomMargin=25)
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("UTITitle", parent=styles["Title"], textColor=colors.HexColor("#173866"), alignment=TA_LEFT, fontSize=15, leading=18)
    subtitle_style = ParagraphStyle("UTISubtitle", parent=styles["Normal"], textColor=colors.HexColor("#63738b"), fontSize=8, leading=11)
    header_style = ParagraphStyle("UTITableHeader", parent=styles["Normal"], textColor=colors.white, fontName="Helvetica-Bold", fontSize=7, leading=8, alignment=TA_CENTER)
    cell_style = ParagraphStyle("UTITableCell", parent=styles["Normal"], textColor=colors.HexColor("#25364d"), fontSize=7, leading=8.5, wordWrap="CJK")
    logo_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static", "images", "logo-teknokrat.png")
    try:
        logo = Image(logo_path, width=42, height=42) if os.path.exists(logo_path) else Paragraph("UTI", title_style)
    except Exception:
        logo = Paragraph("UTI", title_style)
    brand = [Paragraph("UNIVERSITAS TEKNOKRAT INDONESIA", title_style),
             Paragraph(escape(title.upper()), subtitle_style)]
    header = Table([[logo, brand]], colWidths=[52, page_width - 52])
    header.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("BOTTOMPADDING", (0, 0), (-1, -1), 7)]))
    story = [header, Spacer(1, 5)]
    meta_rows = [[Paragraph(f"<b>{escape(str(k))}</b>", cell_style), Paragraph(escape(str(v)), cell_style)] for k, v in metadata]
    if meta_rows:
        meta_table = Table(meta_rows, colWidths=[110, page_width - 110])
        meta_table.setStyle(TableStyle([("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#edf3fb")),
                                        ("TEXTCOLOR", (0, 0), (0, -1), colors.HexColor("#173866")),
                                        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#dbe3ee")),
                                        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                                        ("PADDING", (0, 0), (-1, -1), 6)]))
        story += [meta_table, Spacer(1, 10)]
    data = [[Paragraph(escape(str(value)), header_style) for value in headers]]
    for row in rows:
        data.append([Paragraph(escape(str(value if value is not None else "-")), cell_style) for value in row])
    if not rows:
        data.append([Paragraph("Tidak ada data untuk filter yang dipilih.", cell_style)] + [Paragraph("-", cell_style) for _ in headers[1:]])
    col_width = page_width / max(len(headers), 1)
    table = Table(data, repeatRows=1, colWidths=[col_width] * len(headers))
    table.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#173866")),
                               ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#d8e0eb")),
                               ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f5f8fc")]),
                               ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                               ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                               ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
    story.append(table)
    story.append(Spacer(1, 10))
    story.append(Paragraph("Dokumen dibuat otomatis oleh Sistem Informasi Presensi Mahasiswa Universitas Teknokrat Indonesia.", subtitle_style))
    doc.build(story)
    output.seek(0)
    return send_file(output, as_attachment=True, download_name=filename, mimetype="application/pdf")


@lecturer_bp.route("/")
@login_required
@role_required("lecturer")
def dashboard():
    offerings = ClassOffering.query.filter_by(lecturer_id=current_user.id).order_by(ClassOffering.id.desc()).all()
    offering_ids = [o.id for o in offerings]
    sessions = AttendanceSession.query.filter(AttendanceSession.offering_id.in_(offering_ids)).order_by(AttendanceSession.opened_at.desc()).limit(8).all() if offering_ids else []
    active_count = sum(1 for s in sessions if s.status == "ACTIVE" and s.closes_at > datetime.now())
    todays = []
    weekday = datetime.now().weekday()
    for offering in offerings:
        for schedule in offering.schedules:
            if schedule.weekday == weekday:
                todays.append((offering, schedule))
    schedule_rows = sorted(todays, key=lambda row: row[1].start_time)
    records = _attendance_rows(sessions)
    stat_counts = {"PRESENT": sum(1 for a in records if a.status == "PRESENT"),
                   "LATE": sum(1 for a in records if a.status == "LATE"),
                   "ABSENT": sum(1 for a in records if a.status == "ABSENT")}
    return render_template("lecturer/dashboard.html", page_title="Dashboard Dosen", offerings=offerings,
                           sessions=sessions, active_count=active_count, todays=schedule_rows,
                           stat_counts=stat_counts, now=datetime.now())


@lecturer_bp.route("/classes")
@login_required
@role_required("lecturer")
def classes():
    offerings = ClassOffering.query.filter_by(lecturer_id=current_user.id).order_by(ClassOffering.id.desc()).all()
    return render_template("lecturer/classes.html", page_title="Kelas yang Diampu", offerings=offerings)


@lecturer_bp.route("/enrollments")
@login_required
@role_required("lecturer")
def enrollments():
    status = (request.args.get("status") or "PENDING").upper()
    if status not in ("PENDING", "APPROVED", "REJECTED", "ALL"):
        status = "PENDING"
    query = (db.session.query(CourseEnrollment)
             .join(ClassOffering, ClassOffering.id == CourseEnrollment.offering_id)
             .filter(ClassOffering.lecturer_id == current_user.id))
    if status != "ALL":
        query = query.filter(CourseEnrollment.status == status)
    rows = query.order_by(CourseEnrollment.requested_at.desc()).all()
    pending_count = CourseEnrollment.query.join(ClassOffering, ClassOffering.id == CourseEnrollment.offering_id).filter(
        ClassOffering.lecturer_id == current_user.id, CourseEnrollment.status == "PENDING").count()
    return render_template("lecturer/enrollments.html", page_title="Persetujuan Mahasiswa",
                           enrollments=rows, active_status=status, pending_count=pending_count)


@lecturer_bp.post("/enrollments/<int:enrollment_id>/review")
@login_required
@role_required("lecturer")
def review_enrollment(enrollment_id):
    enrollment = db.get_or_404(CourseEnrollment, enrollment_id)
    if enrollment.offering.lecturer_id != current_user.id:
        abort(403)
    decision = (request.form.get("decision") or "").upper()
    note = (request.form.get("review_note") or "").strip()[:255] or None
    if decision not in ("APPROVED", "REJECTED"):
        flash("Keputusan tidak valid.", "danger")
        return redirect(url_for("lecturer.enrollments"))
    if enrollment.status != "PENDING":
        flash("Pengajuan ini sudah diproses.", "warning")
        return redirect(url_for("lecturer.enrollments"))

    offering = enrollment.offering
    if decision == "APPROVED":
        approved_count = CourseEnrollment.query.filter_by(offering_id=offering.id, status="APPROVED").count()
        if approved_count >= offering.capacity:
            flash("Kapasitas kelas sudah penuh. Pengajuan tidak dapat disetujui.", "danger")
            return redirect(url_for("lecturer.enrollments"))

        approved_enrollments = CourseEnrollment.query.filter_by(
            student_id=enrollment.student_id, status="APPROVED").all()
        target_schedules = list(offering.schedules)
        for existing in approved_enrollments:
            existing_offering = existing.offering
            if existing_offering.semester_id != offering.semester_id:
                continue
            if existing_offering.course_id == offering.course_id:
                flash(
                    f"Mahasiswa sudah mengambil {existing_offering.course.name} pada kelas {existing_offering.class_code}.",
                    "danger",
                )
                return redirect(url_for("lecturer.enrollments"))
            for target_slot in target_schedules:
                for old_slot in existing_offering.schedules:
                    overlaps = (target_slot.weekday == old_slot.weekday
                                and target_slot.start_time < old_slot.end_time
                                and old_slot.start_time < target_slot.end_time)
                    if overlaps:
                        flash(
                            f"Jadwal bentrok dengan {existing_offering.course.name} ({existing_offering.class_code}) "
                            f"pada hari {target_slot.weekday_name}.",
                            "danger",
                        )
                        return redirect(url_for("lecturer.enrollments"))

    enrollment.status = decision
    enrollment.reviewed_at = datetime.now()
    enrollment.reviewed_by_id = current_user.id
    enrollment.review_note = note
    log_action("LECTURER_ENROLLMENT_REVIEW", f"Dosen meninjau pengajuan #{enrollment.id}: {decision}")
    db.session.add(Notification(
        user_id=enrollment.student_id,
        title="Pengajuan mata kuliah diperbarui",
        message=f"Pengajuan {offering.course.name} kelas {offering.class_code}: {'disetujui' if decision == 'APPROVED' else 'ditolak'} oleh dosen pengampu." + (f" Catatan: {note}" if note else ""),
    ))
    db.session.commit()
    flash(f"Pengajuan mahasiswa berhasil {'disetujui' if decision == 'APPROVED' else 'ditolak'}.", "success")
    return redirect(url_for("lecturer.enrollments"))


@lecturer_bp.route("/teaching/add", methods=["GET", "POST"])
@login_required
@role_required("lecturer")
def add_teaching():
    programs = StudyProgram.query.filter_by(is_active=True).order_by(StudyProgram.name).all()
    courses = Course.query.filter_by(is_active=True).order_by(Course.program_id, Course.recommended_semester, Course.code).all()
    semesters = Semester.query.order_by(Semester.id.desc()).all()
    if request.method == "POST":
        mode = (request.form.get("course_entry_mode") or "catalog").lower()
        delivery_mode = (request.form.get("delivery_mode") or "OFFLINE").upper()
        semester = db.session.get(Semester, request.form.get("semester_id", type=int))
        class_code = (request.form.get("class_code") or "").strip().upper()
        capacity = request.form.get("capacity", type=int) or 40
        online_url = (request.form.get("online_url") or "").strip() or None
        course = None
        try:
            if mode == "new":
                code = (request.form.get("new_course_code") or "").strip().upper()
                name = (request.form.get("new_course_name") or "").strip()
                program = db.session.get(StudyProgram, request.form.get("new_program_id", type=int))
                credits = request.form.get("new_credits", type=int) or 2
                rec_sem = request.form.get("new_recommended_semester", type=int)
                course_type = (request.form.get("new_course_type") or "W").upper()
                existing_course = Course.query.filter_by(code=code).first() if code else None
                if existing_course:
                    raise ValueError("Kode mata kuliah sudah ada di katalog. Pilih mata kuliah tersebut dari daftar atau gunakan kode baru.")
                if (not code or not name or not program or credits not in range(1, 7)
                        or rec_sem not in range(1, 9) or course_type not in ("W", "P")):
                    raise ValueError("Lengkapi kode, nama, program studi, semester kurikulum 1–8, SKS, dan jenis mata kuliah baru.")
                course = Course(code=code, name=name, program_id=program.id, credits=credits,
                                recommended_semester=rec_sem, course_type=course_type,
                                description=(request.form.get("new_description") or "").strip() or None,
                                is_active=True)
                db.session.add(course)
                db.session.flush()
            else:
                course = db.session.get(Course, request.form.get("course_id", type=int))
                if not course or not course.is_active:
                    raise ValueError("Pilih mata kuliah aktif dari katalog.")
            if not semester or not semester.is_active:
                raise ValueError("Pilih semester akademik yang aktif.")
            if not class_code or capacity < 1 or delivery_mode not in ("OFFLINE", "ONLINE"):
                raise ValueError("Kode kelas, kapasitas, dan moda perkuliahan wajib valid.")
            if delivery_mode == "ONLINE" and online_url and not online_url.lower().startswith(("https://", "http://")):
                raise ValueError("Tautan online harus dimulai dengan http:// atau https://.")
            slots = _slots_from_form(delivery_mode)
            _validate_conflicts(semester.id, current_user.id, slots, delivery_mode)
            offering = ClassOffering(course=course, semester=semester, lecturer=current_user,
                                     class_code=class_code, capacity=capacity, status="OPEN",
                                     delivery_mode=delivery_mode, online_url=online_url,
                                     created_by_id=current_user.id)
            offering.schedules.extend(ClassSchedule(**slot) for slot in slots)
            db.session.add(offering)
            log_action("LECTURER_OFFERING_CREATE", f"Dosen membuat {course.code} kelas {class_code}; {semester.name}")
            db.session.commit()
            flash("Mata kuliah dan jadwal mengajar berhasil ditambahkan. Kelas tersedia untuk pengambilan mahasiswa.", "success")
            return redirect(url_for("lecturer.classes"))
        except (ValueError, IntegrityError) as exc:
            db.session.rollback()
            flash(str(exc) if isinstance(exc, ValueError) else "Kode kelas sudah digunakan untuk mata kuliah dan semester ini.", "danger")
    return render_template("lecturer/teaching_add.html", page_title="Input Mata Kuliah", programs=programs,
                           courses=courses, semesters=semesters, weekdays=WEEKDAYS)


@lecturer_bp.route("/classes/<int:offering_id>", methods=["GET", "POST"])
@login_required
@role_required("lecturer")
def class_detail(offering_id):
    offering = _owned_offering(offering_id)
    if request.method == "POST":
        session_number = request.form.get("session_number", type=int)
        title = (request.form.get("title") or "").strip() or f"Pertemuan {session_number}"
        open_minutes = request.form.get("open_minutes", type=int)
        grace_minutes = request.form.get("grace_minutes", type=int)
        # Kebijakan saat ini: presensi tidak menggunakan geofence/radius.
        # Field lokasi legacy di AttendanceSession dipertahankan untuk kompatibilitas
        # database lama, tetapi sesi baru selalu membuka pemeriksaan lokasi dalam keadaan nonaktif.
        location_enabled = False
        location_lat = None
        location_lon = None
        radius_m = 100
        if open_minutes is None:
            open_minutes = 10
        if grace_minutes is None:
            grace_minutes = 5

        if offering.status != "OPEN":
            flash("Kelas sudah ditutup. Sesi baru tidak dapat dibuka.", "danger")
        elif not session_number or session_number < 1 or open_minutes < 1 or open_minutes > 180 or grace_minutes < 0 or grace_minutes > 120:
            flash("Nomor pertemuan atau durasi presensi tidak valid.", "danger")
        elif AttendanceSession.query.filter_by(offering_id=offering.id, session_number=session_number).first():
            flash("Nomor pertemuan tersebut sudah digunakan.", "danger")
        else:
            now = datetime.now()
            token = secrets.token_urlsafe(24)
            alphabet = string.ascii_uppercase + string.digits
            code = "".join(secrets.choice(alphabet) for _ in range(6))
            while AttendanceSession.query.filter_by(session_code=code).first():
                code = "".join(secrets.choice(alphabet) for _ in range(6))
            late_after = now + timedelta(minutes=open_minutes)
            closes_at = late_after + timedelta(minutes=grace_minutes)
            session = AttendanceSession(offering_id=offering.id, session_number=session_number,
                title=title, status="ACTIVE", opened_at=now, late_after=late_after,
                closes_at=closes_at, opened_by_id=current_user.id,
                access_token=token, session_code=code,
                location_enabled=location_enabled,
                location_lat=location_lat if location_enabled else None,
                location_lon=location_lon if location_enabled else None,
                radius_m=radius_m if location_enabled else 100)
            db.session.add(session)
            log_action("ATTENDANCE_SESSION_OPEN", f"Membuka sesi {session_number} {offering.course.code} {offering.class_code}; kode {code}; tanpa radius lokasi")
            db.session.commit()
            flash("Sesi presensi dibuka. QR tersedia untuk smartphone dan token untuk laptop/komputer. Verifikasi dilakukan melalui challenge wajah dan liveness.", "success")
            return redirect(url_for("lecturer.session_detail", session_id=session.id))
    enrollments = CourseEnrollment.query.filter_by(offering_id=offering.id, status="APPROVED").all()
    enrollments.sort(key=lambda item: item.student.full_name.lower())
    sessions = AttendanceSession.query.filter_by(offering_id=offering.id).order_by(AttendanceSession.session_number.desc()).all()
    return render_template("lecturer/class_detail.html", page_title=offering.course.name, offering=offering,
                           enrollments=enrollments, sessions=sessions, now=datetime.now())


@lecturer_bp.route("/sessions/<int:session_id>")
@login_required
@role_required("lecturer")
def session_detail(session_id):
    session = _owned_session(session_id)
    try:
        cleanup_expired_evidence(current_app.instance_path)
    except Exception:
        current_app.logger.exception("Pembersihan foto bukti presensi gagal.")
    enrolled_ids = [e.student_id for e in CourseEnrollment.query.filter_by(offering_id=session.offering_id, status="APPROVED").all()]
    existing = {a.student_id: a for a in Attendance.query.filter_by(session_id=session.id).all()}
    rows = []
    evidence_available = {}
    for student_id in enrolled_ids:
        student = db.session.get(User, student_id)
        attendance = existing.get(student_id)
        rows.append((student, attendance))
        if attendance is not None:
            evidence_available[attendance.id] = is_evidence_available(current_app.instance_path, attendance.id)
    rows.sort(key=lambda item: item[0].full_name if item[0] else "")
    qr_data_uri, qr_url = _make_session_qr(session)
    return render_template("lecturer/session_detail.html", page_title="Monitoring Presensi", session=session,
                           rows=rows, evidence_available=evidence_available, now=datetime.now(),
                           qr_data_uri=qr_data_uri, qr_url=qr_url)


@lecturer_bp.route("/attendance/<int:attendance_id>/evidence")
@login_required
@role_required("lecturer")
def attendance_evidence(attendance_id):
    """Serve a short-lived evidence photo only to the lecturer who teaches the class."""
    attendance = db.get_or_404(Attendance, attendance_id)
    if attendance.session.offering.lecturer_id != current_user.id:
        abort(403)
    try:
        cleanup_expired_evidence(current_app.instance_path)
    except Exception:
        current_app.logger.exception("Pembersihan foto bukti presensi gagal.")
    if not is_evidence_available(current_app.instance_path, attendance.id):
        abort(404, description="Foto bukti tidak tersedia atau telah kedaluwarsa.")
    path = evidence_path(current_app.instance_path, attendance.id)
    try:
        response = make_response(send_file(path, mimetype="image/jpeg", as_attachment=False, max_age=0, conditional=False))
    except FileNotFoundError:
        abort(404, description="Foto bukti tidak tersedia atau telah kedaluwarsa.")
    response.headers["Cache-Control"] = "private, no-store, no-cache, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    response.headers["X-Content-Type-Options"] = "nosniff"
    return response


@lecturer_bp.post("/sessions/<int:session_id>/close")
@login_required
@role_required("lecturer")
def close_session(session_id):
    session = _owned_session(session_id)
    if session.status == "CLOSED":
        flash("Sesi sudah ditutup sebelumnya.", "info")
        return redirect(url_for("lecturer.session_detail", session_id=session.id))
    now = datetime.now()
    approved = CourseEnrollment.query.filter_by(offering_id=session.offering_id, status="APPROVED").all()
    existing = {a.student_id for a in Attendance.query.filter_by(session_id=session.id).all()}
    try:
        for enrollment in approved:
            if enrollment.student_id not in existing:
                db.session.add(Attendance(session_id=session.id, student_id=enrollment.student_id,
                    status="ABSENT", checked_in_at=None, verification_method="SESSION_FINALIZATION"))
        session.status = "CLOSED"
        session.closed_at = now
        log_action("ATTENDANCE_SESSION_CLOSE", f"Menutup sesi #{session.session_number} kelas {session.offering.class_code}; finalisasi {len(approved) - len(existing)} data")
        db.session.commit()
        flash("Sesi ditutup dan rekap ketidakhadiran telah difinalisasi.", "success")
    except Exception:
        db.session.rollback()
        flash("Sesi belum berhasil ditutup. Periksa log aplikasi dan coba lagi.", "danger")
    return redirect(url_for("lecturer.session_detail", session_id=session.id))


@lecturer_bp.post("/attendance/<int:attendance_id>/correct")
@login_required
@role_required("lecturer")
def correct_attendance(attendance_id):
    attendance = db.get_or_404(Attendance, attendance_id)
    if attendance.session.offering.lecturer_id != current_user.id:
        abort(403)
    new_status = (request.form.get("status") or "").upper()
    reason = (request.form.get("reason") or "").strip()
    if new_status not in ("PRESENT", "LATE", "ABSENT") or not reason:
        flash("Status dan alasan koreksi wajib diisi.", "danger")
    elif attendance.session.status != "CLOSED":
        flash("Koreksi manual hanya diperbolehkan setelah sesi ditutup.", "warning")
    else:
        attendance.status = new_status
        attendance.correction_reason = reason[:255]
        attendance.corrected_by_id = current_user.id
        if new_status in ("PRESENT", "LATE") and attendance.checked_in_at is None:
            attendance.checked_in_at = datetime.now()
        log_action("ATTENDANCE_MANUAL_CORRECTION", f"Koreksi presensi #{attendance.id} menjadi {new_status}; alasan: {reason}")
        db.session.commit()
        flash("Koreksi presensi berhasil dicatat di log aktivitas.", "success")
    return redirect(url_for("lecturer.session_detail", session_id=attendance.session_id))


@lecturer_bp.route("/schedule")
@login_required
@role_required("lecturer")
def schedule():
    semesters = Semester.query.order_by(Semester.id.desc()).all()
    selected_id = request.args.get("semester_id", type=int)
    selected = db.session.get(Semester, selected_id) if selected_id else get_active_semester()
    query = ClassOffering.query.filter_by(lecturer_id=current_user.id)
    if selected:
        query = query.filter_by(semester_id=selected.id)
    offerings = query.join(ClassOffering.course).order_by(Course.code, ClassOffering.class_code).all()
    rows = [(offering, slot) for offering in offerings for slot in offering.schedules]
    rows.sort(key=lambda row: (row[1].weekday, row[1].start_time))
    return render_template("lecturer/schedule.html", page_title="Jadwal Mengajar", offerings=offerings,
                           schedule_rows=rows, semesters=semesters, selected_semester=selected)


@lecturer_bp.route("/schedule/download.pdf")
@login_required
@role_required("lecturer")
def download_schedule_pdf():
    selected_id = request.args.get("semester_id", type=int)
    selected = db.session.get(Semester, selected_id) if selected_id else get_active_semester()
    query = ClassOffering.query.filter_by(lecturer_id=current_user.id)
    if selected:
        query = query.filter_by(semester_id=selected.id)
    offerings = query.join(ClassOffering.course).order_by(Course.code).all()
    rows = [(o, s) for o in offerings for s in o.schedules]
    rows.sort(key=lambda row: (row[1].weekday, row[1].start_time))
    data = [[slot.weekday_name, f"{slot.start_time:%H:%M}–{slot.end_time:%H:%M}", offering.course.code,
             offering.course.name, offering.class_code, f"{offering.course.credits} SKS",
             offering.delivery_mode_label, offering.lecturer.full_name, slot.room]
            for offering, slot in rows]
    return _build_pdf("Jadwal Mengajar Dosen", [("Dosen", current_user.full_name), ("Semester", selected.name if selected else "Semua Semester")],
                      ["Hari", "Jam", "Kode", "Mata Kuliah", "Kelas", "SKS", "Moda", "Dosen", "Ruang/Online"], data,
                      "jadwal-mengajar.pdf")


@lecturer_bp.route("/schedule/download.xlsx")
@login_required
@role_required("lecturer")
def download_schedule_xlsx():
    selected_id = request.args.get("semester_id", type=int)
    selected = db.session.get(Semester, selected_id) if selected_id else get_active_semester()
    query = ClassOffering.query.filter_by(lecturer_id=current_user.id)
    if selected:
        query = query.filter_by(semester_id=selected.id)
    offerings = query.join(ClassOffering.course).order_by(Course.code).all()
    rows = []
    for offering in offerings:
        for slot in offering.schedules:
            rows.append([slot.weekday_name, slot.start_time.strftime("%H:%M"), slot.end_time.strftime("%H:%M"),
                offering.course.code, offering.course.name, offering.class_code, offering.course.credits,
                offering.course.course_type, offering.delivery_mode_label, offering.lecturer.full_name,
                slot.room, offering.online_url or "-"])
    rows.sort(key=lambda row: (WEEKDAY_NAMES.index(row[0]), row[1]))
    return _build_xlsx("Jadwal Mengajar Dosen", [("Dosen", current_user.full_name), ("Semester", selected.name if selected else "Semua Semester")],
                       ["Hari", "Mulai", "Selesai", "Kode", "Mata Kuliah", "Kelas", "SKS", "W/P", "Moda", "Dosen", "Ruang", "Tautan Online"],
                       rows, "jadwal-mengajar.xlsx")


def _analytics_for_offerings(offerings, closed_sessions):
    """Return course/student attendance summaries based only on finalized sessions."""
    offering_ids = [offering.id for offering in offerings]
    session_ids = [session.id for session in closed_sessions]
    sessions_by_offering = {offering_id: [] for offering_id in offering_ids}
    for session in closed_sessions:
        sessions_by_offering.setdefault(session.offering_id, []).append(session)

    records = _attendance_rows(closed_sessions)
    record_by_key = {(record.session_id, record.student_id): record for record in records}
    enrollments = CourseEnrollment.query.filter(
        CourseEnrollment.offering_id.in_(offering_ids),
        CourseEnrollment.status == "APPROVED",
    ).all() if offering_ids else []
    enrollments_by_offering = {offering_id: [] for offering_id in offering_ids}
    for enrollment in enrollments:
        enrollments_by_offering.setdefault(enrollment.offering_id, []).append(enrollment)

    student_rows = []
    by_offering = []
    distribution = {"PRESENT": 0, "LATE": 0, "ABSENT": 0}
    row_by_key = {}
    for offering in offerings:
        course_sessions = sorted(sessions_by_offering.get(offering.id, []), key=lambda item: (item.session_number, item.opened_at))
        course_total = len(course_sessions)
        course_rows = []
        for enrollment in sorted(enrollments_by_offering.get(offering.id, []), key=lambda item: item.student.full_name.casefold()):
            present = late = 0
            student_records = {}
            for session in course_sessions:
                record = record_by_key.get((session.id, enrollment.student_id))
                status = record.status if record else "ABSENT"
                student_records[session.id] = record
                if status == "PRESENT":
                    present += 1
                elif status == "LATE":
                    late += 1
            absent = max(course_total - present - late, 0)
            percent = round((present + late) * 100.0 / course_total, 1) if course_total else None
            row = {
                "offering": offering,
                "student": enrollment.student,
                "enrollment": enrollment,
                "sessions_total": course_total,
                "present": present,
                "late": late,
                "absent": absent,
                "attended": present + late,
                "percent": percent,
                "session_records": student_records,
            }
            student_rows.append(row)
            course_rows.append(row)
            row_by_key[(offering.id, enrollment.student_id)] = row
            distribution["PRESENT"] += present
            distribution["LATE"] += late
            distribution["ABSENT"] += absent
        valid_percents = [row["percent"] for row in course_rows if row["percent"] is not None]
        by_offering.append({
            "offering": offering,
            "sessions": course_total,
            "students": len(course_rows),
            "present": sum(row["present"] for row in course_rows),
            "late": sum(row["late"] for row in course_rows),
            "absent": sum(row["absent"] for row in course_rows),
            "average_percent": round(sum(valid_percents) / len(valid_percents), 1) if valid_percents else None,
        })

    student_rows.sort(key=lambda row: (row["offering"].course.code, row["offering"].class_code, row["student"].full_name.casefold()))
    return student_rows, by_offering, distribution, row_by_key, sessions_by_offering


def _statistics_scope(period, offering_id=None):
    if period not in ("day", "month", "semester"):
        period = "semester"
    start, end, label = _period_bounds(period)
    query = ClassOffering.query.filter_by(lecturer_id=current_user.id)
    if period == "semester":
        active = get_active_semester()
        if active:
            query = query.filter_by(semester_id=active.id)
    if offering_id:
        query = query.filter_by(id=offering_id)
    offerings = query.join(ClassOffering.course).order_by(Course.code, ClassOffering.class_code).all()
    ids = [offering.id for offering in offerings]
    session_query = AttendanceSession.query.filter(AttendanceSession.offering_id.in_(ids)) if ids else AttendanceSession.query.filter(AttendanceSession.id == -1)
    if start:
        session_query = session_query.filter(AttendanceSession.opened_at >= start)
    if end:
        session_query = session_query.filter(AttendanceSession.opened_at < end)
    sessions = session_query.order_by(AttendanceSession.opened_at.desc()).all()
    finalized_sessions = [session for session in sessions if session.status == "CLOSED"]
    return period, label, offerings, sessions, finalized_sessions


@lecturer_bp.route("/statistics")
@login_required
@role_required("lecturer")
def statistics():
    period = request.args.get("period", "semester")
    selected_offering_id = request.args.get("offering_id", type=int)
    period, period_label, offerings, period_sessions, closed_sessions = _statistics_scope(period, selected_offering_id)
    student_rows, by_offering, distribution, row_by_key, sessions_by_offering = _analytics_for_offerings(offerings, closed_sessions)

    valid_percentages = [row["percent"] for row in student_rows if row["percent"] is not None]
    average_percent = round(sum(valid_percentages) / len(valid_percentages), 1) if valid_percentages else None
    selected_offering = offerings[0] if selected_offering_id and offerings else None
    selected_students = [row for row in student_rows if selected_offering and row["offering"].id == selected_offering.id]
    attention_count = sum(1 for row in selected_students if row["percent"] is not None and row["percent"] < 75.0)
    if not selected_offering:
        attention_count = sum(1 for row in student_rows if row["percent"] is not None and row["percent"] < 75.0)

    selected_student_id = request.args.get("student_id", type=int)
    selected_student_detail = None
    if selected_offering and selected_student_id:
        target = next((row for row in selected_students if row["student"].id == selected_student_id), None)
        if target:
            selected_sessions = sorted(sessions_by_offering.get(selected_offering.id, []), key=lambda item: (item.session_number, item.opened_at))
            detail_rows = []
            for session in selected_sessions:
                record = target["session_records"].get(session.id)
                detail_rows.append({
                    "session": session,
                    "status": record.status if record else "ABSENT",
                    "checked_in_at": record.checked_in_at if record else None,
                    "verification_method": record.verification_method if record else "SESSION_FINALIZATION",
                    "correction_reason": record.correction_reason if record else None,
                })
            selected_student_detail = {"summary": target, "rows": detail_rows}

    if not selected_offering:
        chart_students = []
    else:
        chart_students = selected_students
    distribution_values = [distribution["PRESENT"], distribution["LATE"], distribution["ABSENT"]]
    distribution_total = sum(distribution_values)
    distribution_percentages = [round(value * 100.0 / distribution_total, 1) if distribution_total else 0.0
                                for value in distribution_values]
    chart_payload = {
        "distributionLabels": ["Hadir", "Terlambat", "Tidak Hadir"],
        "distributionValues": distribution_values,
        "distributionPercentages": distribution_percentages,
        "averagePercent": average_percent,
        "studentLabels": [row["student"].full_name for row in chart_students if row["percent"] is not None],
        "studentValues": [row["percent"] for row in chart_students if row["percent"] is not None],
        "classLabels": [row["offering"].course.code + " · " + row["offering"].class_code for row in by_offering],
        "classAverage": [row["average_percent"] if row["average_percent"] is not None else 0 for row in by_offering],
    }
    return render_template(
        "lecturer/statistics.html", page_title="Statistik Kehadiran", offerings=offerings,
        by_offering=by_offering, student_rows=student_rows, counts=distribution,
        sessions=period_sessions, closed_sessions=closed_sessions, period=period,
        period_label=period_label, selected_offering_id=selected_offering.id if selected_offering else None,
        selected_offering=selected_offering, average_percent=average_percent,
        attention_count=attention_count, student_count=len(selected_students) if selected_offering else len(student_rows),
        chart_payload=chart_payload, selected_student_detail=selected_student_detail,
        attendance_warning_threshold=75,
    )


@lecturer_bp.route("/statistics/export.xlsx")
@login_required
@role_required("lecturer")
def export_statistics_xlsx():
    """Create a polished multi-sheet workbook with a selectable course view."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.formatting.rule import DataBarRule, ColorScaleRule
    from openpyxl.chart import DoughnutChart, BarChart, Reference
    from openpyxl.worksheet.datavalidation import DataValidation
    from openpyxl.utils import get_column_letter
    from openpyxl.drawing.image import Image as XLImage

    period = request.args.get("period", "semester")
    # Excel always contains all lecturer-owned offerings in the selected period,
    # even when it was downloaded from a single-course web view. The requested
    # course is used only as the initial dropdown selection on "Persentase Mahasiswa".
    requested_offering_id = request.args.get("offering_id", type=int)
    period, period_label, offerings, period_sessions, closed_sessions = _statistics_scope(period, None)
    allowed_offering_ids = {offering.id for offering in offerings}
    selected_offering_id = requested_offering_id if requested_offering_id in allowed_offering_ids else None
    student_rows, by_offering, distribution, row_by_key, sessions_by_offering = _analytics_for_offerings(offerings, closed_sessions)
    average_values = [row["percent"] for row in student_rows if row["percent"] is not None]
    average_percent = round(sum(average_values) / len(average_values), 1) if average_values else None

    wb = Workbook()
    wb.properties.title = "Statistik Kehadiran Mahasiswa"
    wb.properties.creator = "Universitas Teknokrat Indonesia · Smart Attendance"
    try:
        wb.calculation.fullCalcOnLoad = True
        wb.calculation.forceFullCalc = True
    except Exception:
        pass

    navy, blue, pale, ink, line = "173866", "2F67C9", "F3F7FD", "1F2E45", "DCE5F1"
    green, amber, red, muted = "21865A", "D99A24", "C74755", "71819A"
    thin = Side(style="thin", color=line)
    logo_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static", "images", "logo-teknokrat.png")

    def title_band(sheet, last_col, title, subtitle):
        sheet.sheet_view.showGridLines = False
        sheet.sheet_properties.tabColor = blue
        sheet.merge_cells(start_row=1, start_column=1, end_row=1, end_column=last_col)
        top = sheet.cell(1, 1, "UNIVERSITAS TEKNOKRAT INDONESIA")
        top.font = Font(name="Aptos Display", size=16, bold=True, color="FFFFFF")
        top.fill = PatternFill("solid", fgColor=navy)
        top.alignment = Alignment(vertical="center", horizontal="left")
        for col in range(1, last_col + 1):
            sheet.cell(1, col).fill = PatternFill("solid", fgColor=navy)
        sheet.row_dimensions[1].height = 36
        sheet.merge_cells(start_row=2, start_column=1, end_row=2, end_column=last_col)
        sub = sheet.cell(2, 1, title)
        sub.font = Font(name="Aptos Display", size=13, bold=True, color=navy)
        sub.alignment = Alignment(vertical="center", horizontal="left")
        sheet.row_dimensions[2].height = 28
        sheet.merge_cells(start_row=3, start_column=1, end_row=3, end_column=last_col)
        meta = sheet.cell(3, 1, subtitle)
        meta.font = Font(size=9, color=muted, italic=True)
        meta.alignment = Alignment(vertical="center", wrap_text=True)
        sheet.row_dimensions[3].height = 25
        sheet.freeze_panes = "A7"
        sheet.page_setup.orientation = "landscape"
        sheet.page_setup.fitToWidth = 1
        sheet.page_setup.fitToHeight = 0
        sheet.sheet_properties.pageSetUpPr.fitToPage = True
        sheet.oddFooter.center.text = "Sistem Informasi Presensi Mahasiswa · UTI"
        sheet.oddFooter.right.text = "Halaman &P dari &N"
        sheet.page_margins.left = 0.25
        sheet.page_margins.right = 0.25
        sheet.page_margins.top = 0.45
        sheet.page_margins.bottom = 0.45

    def style_table(sheet, header_row, start_row, end_row, last_col, percent_columns=()):
        for cell in sheet[header_row][:last_col]:
            cell.font = Font(bold=True, color="FFFFFF", size=10)
            cell.fill = PatternFill("solid", fgColor=blue)
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            cell.border = Border(bottom=Side(style="medium", color=navy))
        sheet.row_dimensions[header_row].height = 31
        for row_idx in range(start_row, end_row + 1):
            sheet.row_dimensions[row_idx].height = 22
            for col_idx in range(1, last_col + 1):
                cell = sheet.cell(row_idx, col_idx)
                cell.font = Font(name="Aptos", size=10, color=ink)
                cell.alignment = Alignment(vertical="center", wrap_text=True)
                cell.border = Border(bottom=thin)
                if (row_idx - start_row) % 2 == 1:
                    cell.fill = PatternFill("solid", fgColor=pale)
        for col_idx in percent_columns:
            for row_idx in range(start_row, end_row + 1):
                sheet.cell(row_idx, col_idx).number_format = "0.0%"
        if end_row >= header_row:
            sheet.auto_filter.ref = f"A{header_row}:{get_column_letter(last_col)}{max(end_row, header_row)}"

    def kpi(sheet, col1, col2, label, value, value_format=None):
        sheet.merge_cells(f"{get_column_letter(col1)}5:{get_column_letter(col2)}5")
        sheet.merge_cells(f"{get_column_letter(col1)}6:{get_column_letter(col2)}7")
        lcell = sheet.cell(5, col1, label.upper())
        lcell.fill = PatternFill("solid", fgColor="EAF1FD")
        lcell.font = Font(size=9, bold=True, color=blue)
        lcell.alignment = Alignment(horizontal="center", vertical="center")
        vcell = sheet.cell(6, col1, value)
        vcell.fill = PatternFill("solid", fgColor="F7F9FC")
        vcell.font = Font(name="Aptos Display", size=18, bold=True, color=navy)
        vcell.alignment = Alignment(horizontal="center", vertical="center")
        if value_format:
            vcell.number_format = value_format
        for r in (5, 6, 7):
            for c in range(col1, col2 + 1):
                sheet.cell(r, c).border = Border(left=thin, right=thin, top=thin, bottom=thin)

    # 1. Executive summary dashboard.
    summary = wb.active
    summary.title = "Ringkasan"
    title_band(summary, 10, "DASHBOARD STATISTIK KEHADIRAN", f"Dosen: {current_user.full_name}  |  Periode: {period_label}  |  Dibuat: {datetime.now():%d/%m/%Y %H:%M}")
    kpi(summary, 1, 2, "Mata Kuliah", len(offerings))
    kpi(summary, 3, 4, "Sesi Selesai", len(closed_sessions))
    kpi(summary, 5, 6, "Enrolmen Disetujui", len(student_rows))
    kpi(summary, 7, 8, "Rata-rata Kehadiran", average_percent / 100 if average_percent is not None else None, "0.0%")
    summary["A9"] = "DISTRIBUSI STATUS KEHADIRAN"
    summary["A9"].font = Font(bold=True, size=10, color=navy)
    summary["A10"], summary["B10"] = "Status", "Jumlah"
    for cell in summary[10][:2]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor=blue)
    for row_idx, values in enumerate((("Hadir", distribution["PRESENT"]), ("Terlambat", distribution["LATE"]), ("Tidak Hadir", distribution["ABSENT"])), start=11):
        summary.cell(row_idx, 1, values[0]); summary.cell(row_idx, 2, values[1])
        for cell in summary[row_idx][:2]:
            cell.border = Border(bottom=thin)
            cell.fill = PatternFill("solid", fgColor=pale if row_idx % 2 else "FFFFFF")
    if sum(distribution.values()) > 0:
        donut = DoughnutChart()
        donut.title = "Proporsi Catatan Presensi"
        donut.holeSize = 62
        donut.height = 5.5
        donut.width = 10
        donut.add_data(Reference(summary, min_col=2, min_row=10, max_row=13), titles_from_data=True)
        donut.set_categories(Reference(summary, min_col=1, min_row=11, max_row=13))
        donut.legend.position = "r"
        summary.add_chart(donut, "D9")

    summary["A22"] = "RINGKASAN PER MATA KULIAH"
    summary["A22"].font = Font(bold=True, size=11, color=navy)
    summary_headers = ["Kode", "Mata Kuliah", "Kelas", "Semester", "Sesi Selesai", "Mahasiswa", "Hadir", "Terlambat", "Tidak Hadir", "Rata-rata %"]
    summary_header_row = 23
    for col_idx, value in enumerate(summary_headers, start=1):
        summary.cell(summary_header_row, col_idx, value)
    for row_idx, data in enumerate(by_offering, start=summary_header_row + 1):
        summary.cell(row_idx, 1, data["offering"].course.code)
        summary.cell(row_idx, 2, data["offering"].course.name)
        summary.cell(row_idx, 3, data["offering"].class_code)
        summary.cell(row_idx, 4, data["offering"].semester.name)
        summary.cell(row_idx, 5, data["sessions"])
        summary.cell(row_idx, 6, data["students"])
        summary.cell(row_idx, 7, data["present"])
        summary.cell(row_idx, 8, data["late"])
        summary.cell(row_idx, 9, data["absent"])
        summary.cell(row_idx, 10, data["average_percent"] / 100 if data["average_percent"] is not None else None)
    summary_end = summary_header_row + len(by_offering)
    style_table(summary, summary_header_row, summary_header_row + 1, summary_end, len(summary_headers), percent_columns=(10,))
    for col, width in {"A":13,"B":32,"C":12,"D":24,"E":14,"F":13,"G":12,"H":12,"I":13,"J":16,"K":4}.items():
        summary.column_dimensions[col].width = width
    if os.path.exists(logo_path):
        try:
            logo = XLImage(logo_path); logo.height, logo.width = 27, 27
            summary.add_image(logo, "K1")
        except Exception:
            pass
    summary.print_title_rows = "1:3"
    summary.print_area = f"A1:J{max(summary_end, 23)}"

    # Source-of-truth table. Every approved student is represented for every closed session count;
    # absent rows are explicitly synthesized as ABSENT by _analytics_for_offerings.
    source = wb.create_sheet("Data Rekap")
    title_band(source, 13, "DATA REKAP KEHADIRAN PER MAHASISWA", f"Data sumber untuk filter mata kuliah dan grafik. Rumus: (Hadir + Terlambat) / Sesi Ditutup × 100% · {period_label}")
    source_headers = ["Mata Kuliah / Kelas", "Kode", "Nama Mata Kuliah", "Kelas", "Semester", "NPM", "Nama Mahasiswa", "Sesi Ditutup", "Hadir", "Terlambat", "Tidak Hadir", "Persentase", "Indikator"]
    source_header_row = 6
    for idx, header in enumerate(source_headers, start=1):
        source.cell(source_header_row, idx, header)
    data_row_map = {}
    for idx, data in enumerate(student_rows, start=source_header_row + 1):
        offering, student = data["offering"], data["student"]
        course_key = f"{offering.course.code} · {offering.course.name} · Kelas {offering.class_code}"
        values = [course_key, offering.course.code, offering.course.name, offering.class_code, offering.semester.name,
                  student.npm or "-", student.full_name, data["sessions_total"], data["present"], data["late"], data["absent"]]
        for col_idx, value in enumerate(values, start=1):
            source.cell(idx, col_idx, value)
        source.cell(idx, 12, f'=IF(H{idx}=0,"",(I{idx}+J{idx})/H{idx})')
        source.cell(idx, 13, f'=IF(L{idx}="","Belum ada data",IF(L{idx}<75%,"Perlu perhatian",IF(L{idx}<85%,"Pantau","Baik")))')
        data_row_map[(offering.id, student.id)] = idx
    source_end = source_header_row + len(student_rows)
    style_table(source, source_header_row, source_header_row + 1, source_end, len(source_headers), percent_columns=(12,))
    if source_end >= source_header_row + 1:
        source.conditional_formatting.add(f"L{source_header_row+1}:L{source_end}", DataBarRule(start_type="num", start_value=0, end_type="num", end_value=1, color=blue, showValue=True))
        source.conditional_formatting.add(f"L{source_header_row+1}:L{source_end}", ColorScaleRule(start_type="num", start_value=0, start_color="FDE8E8", mid_type="num", mid_value=0.75, mid_color="FFF2CC", end_type="num", end_value=1, end_color="DDF5E7"))
    for col, width in {"A":43,"B":12,"C":31,"D":12,"E":23,"F":16,"G":28,"H":14,"I":11,"J":12,"K":13,"L":14,"M":20}.items():
        source.column_dimensions[col].width = width
    source.print_title_rows = "1:6"

    # 3. Selectable view with drop-down; FILTER formula requires Excel 365 / Excel Web.
    detail = wb.create_sheet("Persentase Mahasiswa")
    title_band(detail, 13, "PERSENTASE KEHADIRAN PER MAHASISWA", f"Pilih mata kuliah pada sel B5. Daftar ini difilter otomatis berdasarkan sesi yang sudah ditutup. {period_label}")
    detail["A5"] = "PILIH MATA KULIAH / KELAS"
    detail["A5"].font = Font(bold=True, color=navy, size=10)
    detail["A5"].alignment = Alignment(vertical="center")
    detail["B5"] = "Semua Mata Kuliah"
    detail["B5"].font = Font(bold=True, color=navy)
    detail["B5"].fill = PatternFill("solid", fgColor="EAF1FD")
    detail["B5"].alignment = Alignment(vertical="center")
    detail.merge_cells("B5:F5")
    detail.row_dimensions[5].height = 26
    options = ["Semua Mata Kuliah"] + sorted({f"{o.course.code} · {o.course.name} · Kelas {o.class_code}" for o in offerings})
    default_key = None
    if selected_offering_id:
        match_offering = next((o for o in offerings if o.id == selected_offering_id), None)
        if match_offering:
            default_key = f"{match_offering.course.code} · {match_offering.course.name} · Kelas {match_offering.class_code}"
    if default_key:
        detail["B5"] = default_key
    for row_idx, option in enumerate(options, start=1):
        detail.cell(row_idx, 15, option)
    detail.column_dimensions["O"].hidden = True
    dv = DataValidation(type="list", formula1=f"=$O$1:$O${len(options)}", allow_blank=False)
    dv.error = "Pilih mata kuliah dari daftar yang tersedia."
    dv.errorTitle = "Pilihan tidak valid"
    dv.prompt = "Pilih satu mata kuliah / kelas untuk memfilter persentase mahasiswa."
    dv.promptTitle = "Filter mata kuliah"
    detail.add_data_validation(dv); dv.add(detail["B5"])
    detail_headers = source_headers[:]
    view_header_row = 7
    for idx, header in enumerate(detail_headers, start=1):
        detail.cell(view_header_row, idx, header)
    last_source = max(source_end, source_header_row + 1)
    detail["A8"] = (f'=FILTER(\'Data Rekap\'!$A$7:$M${last_source},'
                     f'IF($B$5="Semua Mata Kuliah",\'Data Rekap\'!$A$7:$A${last_source}<>"",'
                     f'\'Data Rekap\'!$A$7:$A${last_source}=$B$5),"Tidak ada data untuk pilihan ini")')
    detail["A8"].font = Font(color=ink, size=10)
    detail["A8"].alignment = Alignment(vertical="center")
    detail.freeze_panes = "A8"
    detail.sheet_properties.pageSetUpPr.fitToPage = True
    detail.page_setup.orientation = "landscape"; detail.page_setup.fitToWidth = 1; detail.page_setup.fitToHeight = 0
    for cell in detail[view_header_row][:len(detail_headers)]:
        cell.font = Font(bold=True, color="FFFFFF", size=10)
        cell.fill = PatternFill("solid", fgColor=blue)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = Border(bottom=Side(style="medium", color=navy))
    detail.row_dimensions[view_header_row].height = 32
    for row_idx in range(8, 8 + max(len(student_rows), 1)):
        detail.row_dimensions[row_idx].height = 23
        for col_idx in range(1, len(detail_headers) + 1):
            cell = detail.cell(row_idx, col_idx)
            cell.font = Font(name="Aptos", size=10, color=ink)
            cell.alignment = Alignment(vertical="center", wrap_text=True)
            cell.border = Border(bottom=thin)
            if (row_idx - 8) % 2 == 1:
                cell.fill = PatternFill("solid", fgColor=pale)
        detail.cell(row_idx, 12).number_format = "0.0%"
    for col, width in {"A":43,"B":12,"C":31,"D":12,"E":23,"F":16,"G":28,"H":14,"I":11,"J":12,"K":13,"L":14,"M":20,"N":3}.items():
        detail.column_dimensions[col].width = width
    if student_rows:
        detail.conditional_formatting.add(f"L8:L{8+len(student_rows)}", DataBarRule(start_type="num", start_value=0, end_type="num", end_value=1, color=blue, showValue=True))
        detail.conditional_formatting.add(f"L8:L{8+len(student_rows)}", ColorScaleRule(start_type="num", start_value=0, start_color="FDE8E8", mid_type="num", mid_value=0.75, mid_color="FFF2CC", end_type="num", end_value=1, end_color="DDF5E7"))
        chart = BarChart()
        chart.type = "bar"
        chart.style = 10
        chart.title = "Persentase Kehadiran per Mahasiswa"
        chart.y_axis.title = "Nama Mahasiswa"
        chart.x_axis.title = "Persentase"
        chart.x_axis.numFmt = "0%"
        chart.x_axis.scaling.min = 0; chart.x_axis.scaling.max = 1
        chart.height = max(7, min(16, 4 + len(student_rows) * 0.25))
        chart.width = 14
        chart.add_data(Reference(detail, min_col=12, min_row=view_header_row, max_row=8+len(student_rows)), titles_from_data=True)
        chart.set_categories(Reference(detail, min_col=7, min_row=8, max_row=8+len(student_rows)))
        detail.add_chart(chart, "O7")

    # 4. Detailed session log including synthetic ABSENT rows for missing records.
    raw = wb.create_sheet("Detail Presensi")
    title_band(raw, 11, "DETAIL PRESENSI PER PERTEMUAN", f"Dosen: {current_user.full_name}  |  Periode: {period_label}")
    raw_headers = ["Kode", "Mata Kuliah", "Kelas", "Pertemuan", "Judul Sesi", "Tanggal", "NPM", "Nama Mahasiswa", "Status", "Waktu Hadir", "Persentase Kelas"]
    rh = 6
    for col_idx, value in enumerate(raw_headers, start=1):
        raw.cell(rh, col_idx, value)
    all_records = _attendance_rows(closed_sessions)
    records_by_session = {}
    for record in all_records:
        records_by_session.setdefault(record.session_id, {})[record.student_id] = record
    detail_index = rh + 1
    for session in sorted(closed_sessions, key=lambda item: (item.offering.course.code, item.offering.class_code, item.session_number)):
        session_records = records_by_session.get(session.id, {})
        roster = CourseEnrollment.query.filter_by(offering_id=session.offering_id, status="APPROVED").all()
        for enrollment in sorted(roster, key=lambda item: item.student.full_name.casefold()):
            record = session_records.get(enrollment.student_id)
            status_value = record.status if record else "ABSENT"
            vals = [session.offering.course.code, session.offering.course.name, session.offering.class_code,
                    session.session_number, session.title, session.opened_at.strftime("%d/%m/%Y"),
                    enrollment.student.npm or "-", enrollment.student.full_name,
                    {"PRESENT":"Hadir", "LATE":"Terlambat", "ABSENT":"Tidak Hadir"}.get(status_value, status_value),
                    record.checked_in_at.strftime("%H:%M:%S") if record and record.checked_in_at else "-"]
            for col_idx, value in enumerate(vals, start=1):
                raw.cell(detail_index, col_idx, value)
            source_idx = data_row_map.get((session.offering_id, enrollment.student_id))
            raw.cell(detail_index, 11, f"='Data Rekap'!L{source_idx}" if source_idx else None)
            detail_index += 1
    raw_end = detail_index - 1
    style_table(raw, rh, rh + 1, raw_end, len(raw_headers), percent_columns=(11,))
    for col, width in {"A":12,"B":30,"C":12,"D":12,"E":30,"F":15,"G":16,"H":28,"I":16,"J":14,"K":16}.items():
        raw.column_dimensions[col].width = width
    raw.print_title_rows = "1:6"

    output = BytesIO()
    wb.save(output)
    output.seek(0)
    filename = f"statistik-kehadiran-{period}.xlsx"
    return send_file(output, as_attachment=True, download_name=filename,
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@lecturer_bp.route("/statistics/export.pdf")
@login_required
@role_required("lecturer")
def export_statistics_pdf():
    period = request.args.get("period", "semester")
    selected_offering_id = request.args.get("offering_id", type=int)
    period, period_label, offerings, period_sessions, closed_sessions = _statistics_scope(period, selected_offering_id)
    student_rows, by_offering, distribution, row_by_key, sessions_by_offering = _analytics_for_offerings(offerings, closed_sessions)
    session_map = {session.id: session for session in closed_sessions}
    records = { (record.session_id, record.student_id): record for record in _attendance_rows(closed_sessions) }
    rows = []
    for session in sorted(closed_sessions, key=lambda item: (item.opened_at, item.offering.course.code)):
        roster = CourseEnrollment.query.filter_by(offering_id=session.offering_id, status="APPROVED").all()
        for enrollment in sorted(roster, key=lambda item: item.student.full_name.casefold()):
            record = records.get((session.id, enrollment.student_id))
            stats = row_by_key.get((session.offering_id, enrollment.student_id))
            status_value = record.status if record else "ABSENT"
            rows.append([
                session.offering.course.code, session.offering.course.name, session.offering.class_code,
                str(session.session_number), session.opened_at.strftime("%d/%m/%Y"),
                enrollment.student.npm or "-", enrollment.student.full_name,
                {"PRESENT":"Hadir", "LATE":"Terlambat", "ABSENT":"Tidak Hadir"}.get(status_value, status_value),
                f"{stats['percent']:.1f}%" if stats and stats["percent"] is not None else "-",
                record.checked_in_at.strftime("%H:%M:%S") if record and record.checked_in_at else "-",
            ])
    rows.sort(key=lambda row: (row[0], row[4], row[5]))
    return _build_pdf("Rekap Presensi Dosen", [
        ("Dosen", current_user.full_name), ("Periode", period_label),
        ("Sesi ditutup", len(closed_sessions)),
        ("Rata-rata kehadiran", f"{sum(row['percent'] for row in student_rows if row['percent'] is not None)/max(1, len([row for row in student_rows if row['percent'] is not None])):.1f}%" if any(row["percent"] is not None for row in student_rows) else "Belum ada data"),
    ], ["Kode", "Mata Kuliah", "Kelas", "Pertemuan", "Tanggal", "NPM", "Mahasiswa", "Status", "Kehadiran", "Waktu"], rows,
        "statistik-kehadiran.pdf")
