﻿$ErrorActionPreference = 'Continue'
$TaskName = 'SmartAttendanceEvidenceCleanup60M'
& schtasks.exe /Delete /TN $TaskName /F
if ($LASTEXITCODE -eq 0) { Write-Host 'Tugas penghapusan otomatis dihapus; foto dan aplikasi tidak dihapus.' -ForegroundColor Green }
else { Write-Host 'Tugas tidak ditemukan atau tidak dapat dihapus.' -ForegroundColor Yellow }
Read-Host 'Tekan ENTER untuk menutup'
