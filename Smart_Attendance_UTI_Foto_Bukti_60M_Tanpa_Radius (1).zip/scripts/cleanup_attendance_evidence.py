#!/usr/bin/env python3
"""Remove Smart Attendance evidence photos after the 60-minute retention period.

This script intentionally uses only the Python standard library so it can run
from Windows Task Scheduler or a Linux cron job, independently of Flask.
"""
from pathlib import Path
import sys
from datetime import datetime

PROJECT_ROOT = Path(__file__).resolve().parents[1]
EVIDENCE_DIR = PROJECT_ROOT / "instance" / "attendance_evidence"
RETENTION_SECONDS = 60 * 60

def main() -> int:
    if not EVIDENCE_DIR.exists():
        print("Folder bukti belum ada; tidak ada file yang perlu dihapus.")
        return 0
    now = __import__("time").time()
    deleted = 0
    failed = 0
    for path in EVIDENCE_DIR.iterdir():
        if not path.is_file():
            continue
        is_evidence = path.name.startswith("attendance_") and path.suffix.lower() == ".jpg"
        is_temp = path.name.startswith(".attendance_") and path.suffix.lower() == ".tmp"
        if not (is_evidence or is_temp):
            continue
        try:
            age = now - path.stat().st_mtime
            limit = RETENTION_SECONDS if is_evidence else 10 * 60
            if age >= limit:
                path.unlink()
                if is_evidence:
                    deleted += 1
        except FileNotFoundError:
            continue
        except OSError as exc:
            failed += 1
            print(f"Gagal menghapus {path.name}: {exc}")
    print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] Foto bukti dihapus: {deleted}; kegagalan: {failed}.")
    return 1 if failed else 0

if __name__ == "__main__":
    raise SystemExit(main())
