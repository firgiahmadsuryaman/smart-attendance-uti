﻿$ErrorActionPreference = 'Stop'
$DefaultTarget = Join-Path $env:USERPROFILE 'Downloads\absensi\smart_attendance'
Write-Host 'PENJADWALAN PENGHAPUSAN FOTO BUKTI SETIAP 1 MENIT' -ForegroundColor Cyan
Write-Host ('Folder proyek: ' + $DefaultTarget) -ForegroundColor Yellow
$InputTarget = Read-Host 'Tekan ENTER jika benar, atau masukkan folder proyek yang berisi run.py'
if ([string]::IsNullOrWhiteSpace($InputTarget)) { $InputTarget = $DefaultTarget }
$ProjectRoot = (Resolve-Path -LiteralPath $InputTarget).Path
$Cleanup = Join-Path $ProjectRoot 'scripts\cleanup_attendance_evidence.py'
if (-not (Test-Path -LiteralPath $Cleanup -PathType Leaf)) { throw "Script cleanup tidak ditemukan: $Cleanup. Jalankan pemasang patch lebih dulu." }
$Python = Join-Path $ProjectRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $Python -PathType Leaf)) {
  $command = Get-Command python.exe -ErrorAction SilentlyContinue
  if (-not $command) { throw 'Python tidak ditemukan. Aktifkan/siapkan Python terlebih dahulu.' }
  $Python = $command.Source
}
$TaskName = 'SmartAttendanceEvidenceCleanup60M'
$TaskCommand = '"' + $Python + '" "' + $Cleanup + '"'
& schtasks.exe /Create /SC MINUTE /MO 1 /TN $TaskName /TR $TaskCommand /F /IT
if ($LASTEXITCODE -ne 0) { throw 'Windows Task Scheduler gagal membuat tugas. Coba jalankan file ini sekali lagi atau buat tugas manual sesuai panduan.' }
Write-Host ''
Write-Host 'Tugas terjadwal berhasil dibuat. Foto kedaluwarsa dibersihkan setiap 1 menit selama pengguna Windows login.' -ForegroundColor Green
Write-Host 'Catatan: pada server Linux, gunakan cron yang menjalankan scripts/cleanup_attendance_evidence.py setiap menit.'
Read-Host 'Tekan ENTER untuk menutup'
