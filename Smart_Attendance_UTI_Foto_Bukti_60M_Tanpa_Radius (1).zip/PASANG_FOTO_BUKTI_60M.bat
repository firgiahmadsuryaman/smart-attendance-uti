@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0PASANG_FOTO_BUKTI_60M.ps1"
if errorlevel 1 (echo. & echo Pemasangan tidak selesai. Ambil screenshot pesan error. & pause)
