@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0HAPUS_JADWAL_PENGHAPUSAN_60M.ps1"
pause
